import React, { Component } from 'react'

export default class Register extends Component {
    render() {
        return (
            <div>
                Register
            </div>
        )
    }
}
