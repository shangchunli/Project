import React, { Component } from 'react'
import { NavBar,Tabs,Card} from 'antd-mobile';

const tabs = [
    { title: '常见疾病' },
    { title: '疫苗接种' }
  ];

export default class Nurse extends Component {
    render() {
        return (
            <div>
                <NavBar
                    style={{backgroundColor:'#fff',color:'#000',
                    height:60,fontWeight:"bolder",
                    position:"fixed",
                    top:"0px",
                    zIndex:100,
                    width:"100%"
                }}
                >
                    宝宝护理
                </NavBar>
                <div style={{marginTop:50}}>
                    <Tabs tabs={tabs} initialPage={2} animated={false} useOnPan={false}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '250px', backgroundColor: '#fff' }}>
                            Content of first tab
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '250px', backgroundColor: '#fff' }}>
                            Content of second tab
                        </div>
                    </Tabs>
                </div>
            </div>
        )
    }
}
