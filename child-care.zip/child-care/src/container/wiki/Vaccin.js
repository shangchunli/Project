import React, { Component } from 'react'

export default class Vaccin extends Component {
    render() {
        return (
            <div>
                Vaccin
            </div>
        )
    }
}
