import React, { Component } from 'react'
import { NavBar, Icon} from 'antd-mobile';
import '../Wiki.css'


export default class Chaowa extends Component {
    
    render() {
        return (
            <ul>
                <NavBar
                    mode="light"
                    icon={<Icon type="left" />}
                    onLeftClick={() => console.log('onLeftClick')}
                        style={{backgroundColor:'#fff',color:'#000'}}
                        
                    >
                        潮娃穿搭
                    </NavBar>
                <li>    
                    <div className='tiezi'style={{ }}>
                        <img  src='./images/chaowa/chaowa1.png'/>
                    <p>潮娃穿搭指南，10岁裴佳欣甜美型</p>
                    <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />
                    </div>
                    <div className='tiezi'style={{ }}>
                        <img  src='./images/chaowa/chaowa2.png'/>
                        <p>跟着潮娃学穿搭，新春挑款攻略一网打尽</p>
                        <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />

                    </div>
                    <div className='tiezi'style={{}}>
                    <img  src='./images/chaowa/chaowa3.png'/>
                        <p>London Scout 的时尚穿搭</p>
                        <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />
                    </div>
                    <div className='tiezi'style={{}}>
                    <img  src='./images/chaowa/chaowa4.png'/>
                        <p>潮娃穿搭风格</p>
                        <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />
                    </div>
                    <div className='tiezi'style={{ }}>
                    <img  src='./images/chaowa/chaowa5.png'/>
                        <p>潮娃穿搭风格</p>
                        <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />
                    </div>
                    <div className='tiezi'style={{ }}>
                    <img  src='./images/chaowa/chaowa6.png'/>
                        <p>潮娃穿搭风格</p>
                        <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />
                    </div>

                </li>
            </ul>
               
        )
    }
}