import React, { Component } from 'react'
import { List, InputItem, WhiteSpace } from 'antd-mobile';
import "./Wiki.css"

export default class Login extends Component {
    render() {
         return (
          <div>
              <div>
              <div style={{backgroundColor:"transparent",width:"100%"
                  ,height:630,opacity:0.4,
              background:"url('./images/beijing/four.jpg') "}}>

                  </div>
              </div>
            <div style={{zIndex:1,position:"fixed",top:130}}>
            <form class="myform">
                <img src="./images/touxiang.jpg" style={{borderRadius:50,
                width:100,height:100}}/>
                <input type="text" autocomplete="off" placeholder="帐号" class="el-input__inner"  id="username" />
                
                <input type="password" autocomplete="off" placeholder="密码" class="el-input__inner"  id="pwd" />
            
                <button type="button" class="el-button login-btn-submit el-button--primary" id="login"><span>登录</span></button>
                <h4>新用户点击注册</h4>
            </form>
            </div>    
            
          </div>
                
        )
    }
}
