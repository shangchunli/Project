import React, { Component } from 'react'

import { NavBar,List } from 'antd-mobile';

const Item = List.Item;


export default class Yiyu extends Component {
    render() {
        return (
            <div>
                 <NavBar
                    style={{backgroundColor:'#fff',
                    color:'#000',position:"fixed",
                    top:"0px",
                    zIndex:100,
                    width:"100%"
                }}
                >
                    抑郁症
                </NavBar>
                <div style={{marginTop:50,height:600
                ,width:"100%",
                    }}>
                    <List>
                        <List.Item style={{paddingTop:10,
                            color:"#000"}}>
                            <img src="./images/touxiang.jpg" style={{float:"right",
                                width:50,height:70,paddingBottom:10}}/>
                                什么是产后抑郁症
                                <List.Item.Brief style={{color:"#000"}}>
                                产后抑郁症是女性精神障碍中...</List.Item.Brief>
                            <List.Item.Brief style={{paddingTop:10}}>丫丫妈妈
                                <span style={{marginLeft:10}}>11月12日</span>
                                <span  style={{marginLeft:20}} onClick={()=>{}}>
                                    <img src="./images/shoucang.svg"/>
                                </span>
                            </List.Item.Brief>
                        </List.Item>
                    </List>
                    <List style={{marginTop:10}}>
                        <List.Item style={{paddingTop:10}}>
                            <img src="./images/touxiang.jpg" style={{float:"right",
                                width:50,height:70,paddingBottom:10}}/>
                                中国每十个产妇就有一个遭产后抑郁：死亡离她很近！ 
                                <List.Item.Brief style={{color:"#000"}}>
                                短短一周时间内，就有两位妈妈跳楼！
                                </List.Item.Brief>
                            <List.Item.Brief style={{paddingTop:10}}>丫丫妈妈
                                <span style={{marginLeft:10}}>11月12日</span>
                                <span  style={{marginLeft:20}} onClick={()=>{}}>
                                    <img src="./images/shoucang.svg"/>
                                </span>
                            </List.Item.Brief>
                        </List.Item>
                    </List>
                    <List style={{marginTop:10}}>
                        <List.Item style={{paddingTop:10}}>
                            <img src="./images/touxiang.jpg" style={{float:"right",
                                width:50,height:70,paddingBottom:10}}/>
                              产后抑郁到底有多可怕？看完这些我沉默了 
                               <List.Item.Brief style={{color:"#000"}}
                               >杭州90后宝妈急诊室门口大喊"救我"后失踪</List.Item.Brief> 

                            <List.Item.Brief style={{paddingTop:10}}>丫丫妈妈
                                <span style={{marginLeft:10}}>11月12日</span>
                                <span  style={{marginLeft:20}} onClick={()=>{}}>
                                    <img src="./images/shoucang.svg"/>
                                </span>
                            </List.Item.Brief>
                        </List.Item>
                    </List>
                    <List style={{marginTop:10}}>
                        <List.Item style={{paddingTop:10}}>
                            <img src="./images/touxiang.jpg" style={{float:"right",
                                width:50,height:70,paddingBottom:10}}/>
                            二胎妈妈带着宝宝从19楼一跃而下：产后抑郁足以毁掉一个女人
                                <List.Item.Brief style={{color:"#000"}}>
                                别再当产后抑郁是矫情了！</List.Item.Brief>
                            <List.Item.Brief style={{paddingTop:10}}>丫丫妈妈
                                <span style={{marginLeft:10}}>11月12日</span>
                                <span  style={{marginLeft:20}} onClick={()=>{}}>
                                    <img src="./images/shoucang.svg"/>
                                </span>
                            </List.Item.Brief>
                        </List.Item>
                    </List>
                    <List style={{marginTop:10}}>
                        <List.Item style={{paddingTop:10}}>
                            <img src="./images/touxiang.jpg" style={{float:"right",
                                width:50,height:70,paddingBottom:10}}/>
                                秦海璐：因巨婴儿子产后抑郁。涅槃重生只因遇见“命定之人”
                                <List.Item.Brief style={{color:"#000"}}>
                                产后抑郁”一直都被认为是一个遥远的名词。直到</List.Item.Brief>
                            <List.Item.Brief style={{paddingTop:10}}>丫丫妈妈
                                <span style={{marginLeft:10}}>11月12日</span>
                                <span  style={{marginLeft:20}} onClick={()=>{}}>
                                    <img src="./images/shoucang.svg"/>
                                </span>
                            </List.Item.Brief>
                        </List.Item>
                    </List>
                    <List style={{marginTop:10}}>
                        <List.Item style={{paddingTop:10}}>
                            <img src="./images/touxiang.jpg" style={{float:"right",
                                width:50,height:70,paddingBottom:10}}/>
                                “本人男，产后抑郁1年”，生娃这件事，男人女人的付出应该平等
                                <List.Item.Brief style={{color:"#000"}}>
                                前几日我收到一位男粉丝的投稿，说他得了产后抑郁</List.Item.Brief>
                            <List.Item.Brief style={{paddingTop:10}}>丫丫妈妈
                                <span style={{marginLeft:10}}>11月12日</span>
                                <span  style={{marginLeft:20}} onClick={()=>{}}>
                                    <img src="./images/shoucang.svg"/>
                                </span>
                            </List.Item.Brief>
                        </List.Item>
                    </List>
                    
                </div>
            </div>
        )
    }
}