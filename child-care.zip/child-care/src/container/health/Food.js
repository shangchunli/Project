import React, { Component } from 'react'
import { WhiteSpace } from 'antd-mobile';
// import { List } from 'antd-mobile';
export default class Food extends Component {
    render() {
        return (
            
            <div>
                <div className='focus1'>
                    <img src='images/momfood/12.png'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;宝妈饮食
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder1'>
                    <img src='images/momfood/35.jpg'
                        style={{width:'17%',height:'92%'}}
                    />
                    &nbsp;&nbsp;&nbsp;哺乳期怎么吃？
                </div>

                <WhiteSpace size="sm" />
                <div className='placeholder1'>
                    <img src='images/momfood/36.jpg'
                        style={{width:'17%',height:'92%'}}
                    />
                    &nbsp;&nbsp;&nbsp;让母乳更有营养，怎么吃？
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder1'>
                    <img src='images/momfood/37.jpg'
                        style={{width:'17%',height:'92%'}}
                    />
                    &nbsp;&nbsp;&nbsp;哺乳期妈妈可不可以吃药？
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder1'>
                    <img src='images/momfood/38.jpg'
                        style={{width:'17%',height:'92%'}}
                    />
                    &nbsp;&nbsp;&nbsp;女人做月子到底可以吃什么蔬菜？
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder1'>
                    <img src='images/momfood/39.jpg'
                        style={{width:'17%',height:'92%'}}
                    />
                    &nbsp;&nbsp;&nbsp;不为人知的剖腹产妇饮食注意事项
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder1'>
                    <img src='images/momfood/40.jpg'
                        style={{width:'17%',height:'92%'}}
                    />
                    &nbsp;&nbsp;&nbsp;坐月子饮食禁忌，你注意到了吗？
                </div>
                
                
            </div>
        )
    }
}
