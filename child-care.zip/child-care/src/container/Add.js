import React, { Component } from 'react'
import Reply from './health/Reply'
import Chinese from './home/Chinese'
import Picture from './home/Picture'
import Nurse from './wiki/Nurse'
import Chaowa from './wiki/Chaowa'
import Tongyong from './my/Tongyong'
import Youxi from './home/Youxi'
import Yiyu from './health/Yiyu'
import Anxiety from './health/Anxiety'
import Unique from './my/Unique'
import BabyFood from './wiki/BabyFood'
import Edu from './wiki/Edu'
import Food from './health/Food'
import Focus from './my/Focus'
import Story from './home/Story'
import Song from './home/Song'

export default class Add extends Component {
    render() {
        return (
            <div>
                {/* <Reply/> */}
                {/* <Chinese/> */}
                {/* <Picture/> */}
                {/* <Nurse/> */}
                {/* <Chaowa/> */}
                {/* <Tongyong/> */}
                {/* <Youxi/> */}
                {/* <Yiyu/> */}
                {/* <Anxiety/> */}
                {/* <Unique/> */}
                {/* <BabyFood/> */}
                {/* <Edu/> */}
                {/* <Food/> */}
                {/* <Focus/> */}
                {/* <Story/> */}
                <Song/>
            </div>
        )
    }
}
