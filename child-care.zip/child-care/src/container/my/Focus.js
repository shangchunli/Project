import React, { Component } from 'react'
import { WhiteSpace } from 'antd-mobile';
import "./collect.css"
// import { List } from 'antd-mobile';
export default class Focus extends Component {
    render() {
        return (
            
            <div>
                <div className='focus1'>
                    <img src='images/momfood/12.png'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;我的关注
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder'>
                    <img src='images/11.jpg'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;小美妈妈
                </div>

                <WhiteSpace size="sm" />
                <div className='placeholder'>
                    <img src='images/11.jpg'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;小美妈妈
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder'>
                    <img src='images/11.jpg'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;小美妈妈
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder'>
                    <img src='images/11.jpg'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;小美妈妈
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder'>
                    <img src='images/11.jpg'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;小美妈妈
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder'>
                    <img src='images/11.jpg'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;小美妈妈
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder'>
                    <img src='images/11.jpg'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;小美妈妈
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder'>
                    <img src='images/11.jpg'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;小美妈妈
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder'>
                    <img src='images/11.jpg'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;小美妈妈
                </div>
                <WhiteSpace size="sm" />
                <div className='placeholder'>
                    <img src='images/11.jpg'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;小美妈妈
                </div>
                <WhiteSpace size="sm" />
                
                
            </div>
        )
    }
}
