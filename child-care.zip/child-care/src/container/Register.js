import React, { Component } from 'react'
import {List,WingBlank,Button} from "antd-mobile"
import "./Wiki.css"
export default class Register extends Component {
    render() {
        return (
            <div style={{marginTop:50}}>
                <img src="./images/touxiang.jpg" style={{width:100,height:100,
                borderRadius:50,marginLeft:"30%",marginBottom:50}}/>
                 <List style={{width:"80%",margin:"0 auto"}} className="register">
                    <List.Item
                    thumb="https://zos.alipayobjects.com/rmsportal/dNuvNrtqUztHCwM.png"
                    >
                        <input type="text" placeholder="昵称" name="ni"/>
                    </List.Item>
                </List>
                <List style={{width:"80%",margin:"0 auto",paddingTop:20}} className="register">
                    <List.Item
                    thumb="https://zos.alipayobjects.com/rmsportal/dNuvNrtqUztHCwM.png"
                    >
                        <input type="telphone" placeholder="手机号" name="tel"/>
                    </List.Item>
                </List>
                <List style={{width:"80%",margin:"0 auto",paddingTop:20}} className="register">
                    <List.Item
                    thumb="https://zos.alipayobjects.com/rmsportal/dNuvNrtqUztHCwM.png"
                    >
                        <input type="email" placeholder="邮箱" name="email"/>
                    </List.Item>
                </List>
                <List style={{width:"80%",margin:"0 auto",paddingTop:20}} className="register">
                    <List.Item
                    thumb="https://zos.alipayobjects.com/rmsportal/dNuvNrtqUztHCwM.png"
                    >
                        <input type="password" placeholder="密码" name="pwd1"/>
                    </List.Item>
                </List>
                <List style={{width:"80%",margin:"0 auto",paddingTop:20}} className="register">
                    <List.Item
                    thumb="https://zos.alipayobjects.com/rmsportal/dNuvNrtqUztHCwM.png"
                    >
                        <input type="password" placeholder="密码" name="pwd2"/>
                    </List.Item>
                </List>
                <List style={{width:"100%",margin:"0 auto",paddingTop:20}}>
                <List.Item
      extra={<Button type="primary" size="small" inline>提交</Button>}
      multipleLine
    ></List.Item>
                </List>
            </div>
        )
    }
}



