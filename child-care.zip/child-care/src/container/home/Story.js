import React, { Component } from 'react'
import { Flex, WhiteSpace } from 'antd-mobile';
import './song.css'
export default class Story extends Component {
    render() {
        return (
            
            <div>
                <div className='focus1'>
                    <img src='images/12.png'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;睡前小故事
                </div>
                    <WhiteSpace size="lg" />
                    <Flex >
                    <Flex.Item>
                        <div className='song2'
                        style={{background:"url('./images/song/26.jpg')"
                        }}>
                            
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/27.jpg")',backgroundSize:'cover'}}>
                            
                           
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/28.jpg")',backgroundSize:'cover'}}>
                            
                           
                        </div>
                        
                    </Flex.Item>
                    </Flex>
                    <span style={{paddingLeft:'8%'}}>小红帽</span>
                    <span style={{paddingLeft:'20%'}}>三只小猪</span>
                    <span style={{paddingLeft:'20%'}}>木偶奇遇记</span>               
                    <WhiteSpace size="lg" />
                    <Flex>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/29.jpg")',backgroundSize:'cover'}}>
                            
                          
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/30.jpg")',backgroundSize:'cover'}}>
                            
                          
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/31.jpg")',backgroundSize:'cover'}}>
                            
                            
                        </div>
                        
                    </Flex.Item>
                    </Flex>
                    <span style={{paddingLeft:'8%'}}>小马过河</span>
                    <span style={{paddingLeft:'20%'}}>小猫钓鱼</span>
                    <span style={{paddingLeft:'13%'}}>善良的三角龙</span>
                    <WhiteSpace size="lg" />
                    <Flex>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/32.jpg")',backgroundSize:'cover'}}>
                            
                            
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/33.jpg")',backgroundSize:'cover'}}>
                            
                            
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/34.jpg")',backgroundSize:'cover'}}>
                            
                           
                        </div>
                        
                    </Flex.Item>
                    </Flex>
                    <span style={{paddingLeft:'8%'}}>白雪公主</span>
                    <span style={{paddingLeft:'20%'}}>丑小鸭</span>
                    <span style={{paddingLeft:'20%'}}>孔融让梨</span>
            </div>
        )
    }
}
