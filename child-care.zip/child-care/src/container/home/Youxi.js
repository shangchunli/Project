import React, { Component } from 'react'
import { NavBar, Icon} from 'antd-mobile';
import '../Wiki.css'


export default class Youxi extends Component {
    
    render() {
        return (
            <ul>
                <NavBar
                    mode="light"
                    icon={<Icon type="left" />}
                    onLeftClick={() => console.log('onLeftClick')}
                        style={{backgroundColor:'#fff',color:'#000'}}
                        
                    >
                        亲子游戏
                    </NavBar>
                <li>    
                    <div className='tiezi'style={{ }}>
                        <img  src='./images/chaowa/youxi1.png'/>
                    <p>寿司卷--棉被小道具</p>
                    <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />
                    </div>
                    <div className='tiezi'style={{ }}>
                    <img  src='./images/chaowa/youxi2.png'/>
                    <p>荡秋千--棉被小道具</p>
                        <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />

                    </div>
                    <div className='tiezi'style={{}}>
                    <img  src='./images/chaowa/youxi1.png'/>
                    <p>拉雪橇--棉被小道具</p>
                        <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />
                    </div>
                    <div className='tiezi'style={{}}>
                    <img  src='./images/chaowa/youxi2.png'/>
                    <p>捞金鱼--脸盆小道具</p>
                        <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />
                    </div>
                    <div className='tiezi'style={{ }}>
                    <img  src='./images/chaowa/youxi2.png'/>
                    <p>泡澡好好玩--脸盆小道具</p>
                        <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />
                    </div>
                    <div className='tiezi'style={{ }}>
                    <img  src='./images/chaowa/youxi2.png'/>
                    <p>小小模特儿--脸盆小道具</p>
                        <img style={{height:20,width:20,float:'right',marginTop:-30,marginRight:10}}  src='./images/chaowa/shoucang.svg' />
                    </div>

                </li>
            </ul>
               
        )
    }
}