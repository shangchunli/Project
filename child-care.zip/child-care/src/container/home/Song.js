import React, { Component } from 'react'
import { Flex, WhiteSpace } from 'antd-mobile';
import "./song.css"
export default class Song extends Component {
    render() {
        return (
            
            <div>
                <div className='focus1'>
                    <img src='./images/momfood/12.png'
                        style={{width:'12%',height:'88%'}}
                    />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;宝宝催眠曲
                </div>
                    <WhiteSpace size="lg" />
                    <Flex>
                    <Flex.Item>
                        <div className='song2'style={{background:"url('./images/song/13.jpg')",backgroundSize:'cover',opacity:'0.9'}}>
                            
                            <img 
                                src='./images/song/25.png'
                                style={{paddingLeft:'60%',paddingTop:'60%'}}
                                />
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("./images/song/14.jpg")',backgroundSize:'cover',opacity:'0.9'}}>
                            
                            <img 
                                src='./images/song/25.png'
                                style={{paddingLeft:'60%',paddingTop:'60%'}}
                                />
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/15.jpg")',backgroundSize:'cover',opacity:'0.7'}}>
                            
                            <img 
                                src='images/song/25.png'
                                style={{paddingLeft:'60%',paddingTop:'60%'}}
                                />
                        </div>
                        
                    </Flex.Item>
                    </Flex>
                    <span style={{paddingLeft:'8%'}}>轻音乐</span>
                    <span style={{paddingLeft:'20%'}}>3D催眠曲</span>
                    <span style={{paddingLeft:'20%'}}>轻柔纯音乐</span>               
                    <WhiteSpace size="lg" />
                    <Flex>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/16.jpg")',backgroundSize:'cover',opacity:'0.9'}}>
                            
                            <img 
                                src='images/song/25.png'
                                style={{paddingLeft:'60%',paddingTop:'60%'}}
                                />
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/17.jpg")',backgroundSize:'cover',opacity:'0.9'}}>
                            
                            <img 
                                src='images/song/25.png'
                                style={{paddingLeft:'60%',paddingTop:'60%'}}
                                />
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/18.jpg")',backgroundSize:'cover',opacity:'0.7'}}>
                            
                            <img 
                                src='images/song/25.png'
                                style={{paddingLeft:'60%',paddingTop:'60%'}}
                                />
                        </div>
                        
                    </Flex.Item>
                    </Flex>
                    <span style={{paddingLeft:'8%'}}>轻音乐</span>
                    <span style={{paddingLeft:'20%'}}>3D催眠曲</span>
                    <span style={{paddingLeft:'20%'}}>轻柔纯音乐</span>
                    <WhiteSpace size="lg" />
                    <Flex>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/19.jpg")',backgroundSize:'cover',opacity:'0.9'}}>
                            
                            <img 
                                src='images/song/25.png'
                                style={{paddingLeft:'60%',paddingTop:'60%'}}
                                />
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/20.jpg")',backgroundSize:'cover',opacity:'0.9'}}>
                            
                            <img 
                                src='images/song/25.png'
                                style={{paddingLeft:'60%',paddingTop:'60%'}}
                                />
                        </div>
                        
                    </Flex.Item>
                    <Flex.Item>
                        <div className='song2'style={{background:'url("images/song/21.jpg")',backgroundSize:'cover',opacity:'0.7'}}>
                            
                            <img 
                                src='images/song/25.png'
                                style={{paddingLeft:'60%',paddingTop:'60%'}}
                                />
                        </div>
                        
                    </Flex.Item>
                    </Flex>
                    <span style={{paddingLeft:'8%'}}>轻音乐</span>
                    <span style={{paddingLeft:'20%'}}>3D催眠曲</span>
                    <span style={{paddingLeft:'20%'}}>轻柔纯音乐</span>
            </div>
        )
    }
}
