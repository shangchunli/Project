import React, { Component } from 'react'
import AppTab from './container/AppTab'
import Bottom from './container/Bottom'
import Wiki from './container/Wiki'
import {BrowserRouter as Router,Route,Link} from "react-router-dom"
import Login from './container/Login'
import Picture from './container/home/Picture'
import Song from './container/home/Song'
import Register from './container/Register'
export default class App extends Component {
    render() {
        return (
            <div>
                <AppTab/>
                {/* <Login/> */}
                {/* <Register/> */}
            </div>
            // <Router>
                
            //     <div>
            //         <Route path="/home" component={AppTab} />
            //         <Route path="/wiki" component={Wiki}/>
            //         <Route path="/pic" component={Picture}/>
            //         <Route path="/song" component={Song}/>
            //         <Route path="/bottom" component={Bottom}/>
            //     </div>
            //     <div>
            //         <Link to="/home"></Link>
            //         <Link to="/pic"></Link>
            //         <Link to="/bottom"></Link>
            //         <Link to="/song"></Link>
            //     </div>
            //     <Bottom/>
            // </Router>
        )
    }
}